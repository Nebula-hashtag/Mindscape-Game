extends Control

@export var helmet_color: Color = Color(0.01, 0.03, 0.05, 0.90)

@export var offscreen_extend: float = 220.0
@export var curve_steps: int = 36

@export var side_edge_inset: float = 24.0
@export var side_mid_bulge: float = 58.0

@export var top_rim_height: float = 20.0
@export var top_curve_depth: float = 10.0

@export var bottom_rim_height: float = 24.0
@export var bottom_curve_depth: float = 20.0

@export var overlay_z_index: int = -50


var left_shape: Polygon2D
var right_shape: Polygon2D
var top_shape: Polygon2D
var bottom_shape: Polygon2D


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	offset_left = 0.0
	offset_top = 0.0
	offset_right = 0.0
	offset_bottom = 0.0

	left_shape = ensure_polygon("LeftShape")
	right_shape = ensure_polygon("RightShape")
	top_shape = ensure_polygon("TopShape")
	bottom_shape = ensure_polygon("BottomShape")

	if not resized.is_connected(_on_resized):
		resized.connect(_on_resized)

	call_deferred("rebuild_overlay")


func _on_resized() -> void:
	rebuild_overlay()


func ensure_polygon(node_name: String) -> Polygon2D:
	var poly: Polygon2D

	if has_node(node_name):
		poly = get_node(node_name) as Polygon2D
	else:
		poly = Polygon2D.new()
		poly.name = node_name
		add_child(poly)

	poly.color = helmet_color
	poly.z_as_relative = true
	poly.z_index = overlay_z_index
	return poly


func rebuild_overlay() -> void:
	var w: float = size.x
	var h: float = size.y

	if w <= 0.0 or h <= 0.0:
		var viewport_size: Vector2 = get_viewport_rect().size
		w = viewport_size.x
		h = viewport_size.y

	left_shape.color = helmet_color
	right_shape.color = helmet_color
	top_shape.color = helmet_color
	bottom_shape.color = helmet_color

	left_shape.polygon = build_left_polygon(w, h, offscreen_extend)
	right_shape.polygon = build_right_polygon(w, h, offscreen_extend)
	top_shape.polygon = build_top_polygon(w, h, offscreen_extend)
	bottom_shape.polygon = build_bottom_polygon(w, h, offscreen_extend)


func build_left_polygon(w: float, h: float, ext: float) -> PackedVector2Array:
	var poly: PackedVector2Array = PackedVector2Array()

	var top_inner: Vector2 = Vector2(side_edge_inset, -ext)
	var mid_inner: Vector2 = Vector2(side_mid_bulge, h * 0.5)
	var bottom_inner: Vector2 = Vector2(side_edge_inset, h + ext)

	poly.append(Vector2(-ext, -ext))
	poly.append(Vector2(-ext, h + ext))
	poly.append(bottom_inner)

	var lower_curve: PackedVector2Array = sample_quadratic(
		bottom_inner,
		Vector2(side_mid_bulge, h * 0.75),
		mid_inner,
		curve_steps
	)

	for p: Vector2 in lower_curve:
		poly.append(p)

	var upper_curve: PackedVector2Array = sample_quadratic(
		mid_inner,
		Vector2(side_mid_bulge, h * 0.25),
		top_inner,
		curve_steps
	)

	for i: int in range(1, upper_curve.size()):
		poly.append(upper_curve[i])

	return poly


func build_right_polygon(w: float, h: float, ext: float) -> PackedVector2Array:
	var poly: PackedVector2Array = PackedVector2Array()

	var top_inner: Vector2 = Vector2(w - side_edge_inset, -ext)
	var mid_inner: Vector2 = Vector2(w - side_mid_bulge, h * 0.5)
	var bottom_inner: Vector2 = Vector2(w - side_edge_inset, h + ext)

	poly.append(Vector2(w + ext, -ext))
	poly.append(Vector2(w + ext, h + ext))
	poly.append(bottom_inner)

	var lower_curve: PackedVector2Array = sample_quadratic(
		bottom_inner,
		Vector2(w - side_mid_bulge, h * 0.75),
		mid_inner,
		curve_steps
	)

	for p: Vector2 in lower_curve:
		poly.append(p)

	var upper_curve: PackedVector2Array = sample_quadratic(
		mid_inner,
		Vector2(w - side_mid_bulge, h * 0.25),
		top_inner,
		curve_steps
	)

	for i: int in range(1, upper_curve.size()):
		poly.append(upper_curve[i])

	return poly


func build_top_polygon(w: float, h: float, ext: float) -> PackedVector2Array:
	var poly: PackedVector2Array = PackedVector2Array()

	var left_inner: Vector2 = Vector2(-ext, top_rim_height)
	var center_inner: Vector2 = Vector2(w * 0.5, top_rim_height + top_curve_depth)
	var right_inner: Vector2 = Vector2(w + ext, top_rim_height)

	poly.append(Vector2(-ext, -ext))
	poly.append(Vector2(w + ext, -ext))
	poly.append(right_inner)

	var curve: PackedVector2Array = sample_quadratic(
		right_inner,
		center_inner,
		left_inner,
		curve_steps
	)

	for p: Vector2 in curve:
		poly.append(p)

	return poly


func build_bottom_polygon(w: float, h: float, ext: float) -> PackedVector2Array:
	var poly: PackedVector2Array = PackedVector2Array()

	var left_inner: Vector2 = Vector2(-ext, h - bottom_rim_height)
	var center_inner: Vector2 = Vector2(w * 0.5, h - bottom_rim_height - bottom_curve_depth)
	var right_inner: Vector2 = Vector2(w + ext, h - bottom_rim_height)

	poly.append(Vector2(-ext, h + ext))
	poly.append(Vector2(w + ext, h + ext))
	poly.append(right_inner)

	var curve: PackedVector2Array = sample_quadratic(
		right_inner,
		center_inner,
		left_inner,
		curve_steps
	)

	for p: Vector2 in curve:
		poly.append(p)

	return poly


func sample_quadratic(start_point: Vector2, control_point: Vector2, end_point: Vector2, steps: int) -> PackedVector2Array:
	var points: PackedVector2Array = PackedVector2Array()
	var safe_steps: int = maxi(steps, 2)

	for i: int in range(safe_steps + 1):
		var t: float = float(i) / float(safe_steps)
		var a: Vector2 = start_point.lerp(control_point, t)
		var b: Vector2 = control_point.lerp(end_point, t)
		var point: Vector2 = a.lerp(b, t)
		points.append(point)

	return points
