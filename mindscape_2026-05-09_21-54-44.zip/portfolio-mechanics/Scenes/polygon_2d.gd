extends Polygon2D

func _ready() -> void:
	polygon = PackedVector2Array([
		Vector2(0, 0),
		Vector2(330, 0),
		Vector2(360, 35),
		Vector2(360, 260),
		Vector2(25, 260),
		Vector2(0, 235)
	])

	color = Color(0.02, 0.05, 0.07, 0.65)
	antialiased = true
