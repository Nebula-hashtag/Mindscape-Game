extends CanvasLayer

############################################################
# PLAYER UI
#
# Handles:
# - Health bar
# - Stamina bar
# - Helmet drift
# - Damage flash
# - Wave announcement
# - Stats text:
#   Level, kills, damage, regen, armour, speed, jump,
#   active items and powerups
############################################################


############################################################
# REFERENCES
############################################################

@export var player: CharacterBody3D

@export var health_bar: ProgressBar
@export var stamina_bar: ProgressBar

@export var helmet_layer: Control
@export var damage_flash: ColorRect

@export var wave_label: Label
@export var stats_label: Label


############################################################
# HELMET DRIFT SETTINGS
############################################################

@export var drift_amount: float = 12.0
@export var drift_speed: float = 8.0

@export var jump_drift_amount: float = 18.0
@export var recoil_drift_amount: float = 10.0

var target_offset: Vector2 = Vector2.ZERO


############################################################
# DAMAGE FLASH SETTINGS
############################################################

@export var flash_fade_speed: float = 4.0
var last_health: float = 0.0


############################################################
# SETUP
############################################################

func _ready() -> void:
	add_to_group("player_ui")

	if player == null:
		player = get_tree().get_first_node_in_group("player")

	if player == null:
		print("PlayerUI: Player not assigned and no player found in group.")
		return

	last_health = player.health

	if health_bar != null:
		health_bar.max_value = player.max_health
		health_bar.value = player.health
		style_bar(health_bar, Color(0.35, 1.0, 0.65, 1.0))

	if stamina_bar != null:
		stamina_bar.max_value = player.max_stamina
		stamina_bar.value = player.stamina
		style_bar(stamina_bar, Color(1.0, 0.65, 0.2, 1.0))

	if damage_flash != null:
		damage_flash.color = Color(1, 0, 0, 0)

	if wave_label != null:
		wave_label.visible = false
		wave_label.text = ""


############################################################
# UPDATE
############################################################

func _process(delta: float) -> void:
	if player == null:
		return

	update_bars()
	handle_helmet_drift(delta)
	handle_damage_flash(delta)
	update_stats()


############################################################
# BARS
############################################################

func update_bars() -> void:
	if health_bar != null:
		health_bar.max_value = player.max_health
		health_bar.value = player.health

	if stamina_bar != null:
		stamina_bar.max_value = player.max_stamina
		stamina_bar.value = player.stamina


############################################################
# HELMET DRIFT
############################################################

func handle_helmet_drift(delta: float) -> void:
	if helmet_layer == null:
		return

	var mouse_velocity: Vector2 = Input.get_last_mouse_velocity()

	var controller_look: Vector2 = Vector2(
		Input.get_joy_axis(0, JOY_AXIS_RIGHT_X),
		Input.get_joy_axis(0, JOY_AXIS_RIGHT_Y)
	)

	var combined_input: Vector2 = Vector2(
		(-mouse_velocity.x * 0.015) + (-controller_look.x * 12.0),
		(-mouse_velocity.y * 0.015) + (-controller_look.y * 12.0)
	)

	target_offset = Vector2(
		clamp(combined_input.x, -drift_amount, drift_amount),
		clamp(combined_input.y, -drift_amount, drift_amount)
	)

	target_offset.y += player.velocity.y * -0.9

	if "ui_jump_kick" in player:
		target_offset.y += player.ui_jump_kick * jump_drift_amount

	if "ui_recoil_kick" in player:
		target_offset.y += player.ui_recoil_kick * recoil_drift_amount

	helmet_layer.position = helmet_layer.position.lerp(
		target_offset,
		drift_speed * delta
	)


############################################################
# DAMAGE FLASH
############################################################

func handle_damage_flash(delta: float) -> void:
	if damage_flash == null:
		return

	if player.health < last_health:
		damage_flash.color.a = 0.45

	damage_flash.color.a = lerp(
		damage_flash.color.a,
		0.0,
		flash_fade_speed * delta
	)

	last_health = player.health


############################################################
# WAVE ANNOUNCEMENT
############################################################

func announce_wave(
	wave_number: int,
	player_level: int,
	enemy_level: int
) -> void:
	if wave_label == null:
		print("WaveLabel not assigned")
		return

	wave_label.visible = true

	wave_label.text = (
		"WAVE " + str(wave_number) +
		"\nPLAYER LEVEL " + str(player_level) +
		"\nENEMY LEVEL " + str(enemy_level)
	)

	await get_tree().create_timer(4.0).timeout

	if wave_label != null:
		wave_label.visible = false


############################################################
# STATS UI
############################################################

func update_stats() -> void:
	if stats_label == null:
		return

	if not player.has_method("get_stats_for_ui"):
		return

	var stats: Dictionary = player.get_stats_for_ui()
	update_stats_text(stats)


func update_stats_text(stats: Dictionary) -> void:
	var active_items_text: String = get_array_text(stats["active_items"])
	var powerups_text: String = get_powerup_text(stats["powerups"])

	stats_label.text = (
		"LEVEL: %s\n" %
		stats["level"]

		+ "Kills: %s / %s\n" %
		[stats["kills_this_level"], stats["kills_required"]]

		+ "Total Kills: %s\n\n" %
		stats["kills"]

		+ "Health: %.0f / %.0f  |  %.2fx\n" %
		[stats["health"], stats["max_health"], stats["health_multiplier"]]

		+ "Stamina: %.0f / %.0f\n" %
		[stats["stamina"], stats["max_stamina"]]

		+ "Damage: %s  |  %.2fx\n" %
		[stats["damage"], stats["damage_multiplier"]]

		+ "Regen: %.1f/s  |  %.2fx\n" %
		[stats["regen"], stats["regen_multiplier"]]

		+ "Armour: %.2fx\n" %
		stats["armour_multiplier"]

		+ "Speed: %.2fx\n" %
		stats["speed_multiplier"]

		+ "Jump: %.2fx\n\n" %
		stats["jump_multiplier"]

		+ "Active Items:\n%s\n\n" %
		active_items_text

		+ "Powerups:\n%s" %
		powerups_text
	)


############################################################
# TEXT HELPERS
############################################################

func get_array_text(items: Array) -> String:
	if items.is_empty():
		return "- None"

	var text: String = ""

	for item in items:
		text += "- %s\n" % item

	return text.strip_edges()


func get_powerup_text(powerups: Dictionary) -> String:
	if powerups.is_empty():
		return "- None"

	var text: String = ""

	for powerup_name in powerups.keys():
		text += "- %s x%s\n" % [powerup_name, powerups[powerup_name]]

	return text.strip_edges()


############################################################
# UI STYLE
############################################################

func style_bar(bar: ProgressBar, fill_color: Color) -> void:
	if bar == null:
		return

	var background := StyleBoxFlat.new()
	background.bg_color = Color(0.03, 0.04, 0.04, 0.75)
	background.border_color = Color(0.45, 0.55, 0.55, 1.0)
	background.set_border_width_all(2)
	background.set_corner_radius_all(0)

	var fill := StyleBoxFlat.new()
	fill.bg_color = fill_color
	fill.set_corner_radius_all(0)

	bar.add_theme_stylebox_override("background", background)
	bar.add_theme_stylebox_override("fill", fill)
	bar.show_percentage = false
