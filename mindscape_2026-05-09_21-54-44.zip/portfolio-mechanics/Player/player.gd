extends CharacterBody3D

############################################################
# PLAYER CONTROLLER
#
# Includes:
# - First-person movement
# - Mouse/controller look
# - Sprint stamina with recharge delay
# - Jumping
# - Health, regen, armour and death
# - Shooting with raycast
# - Dash and ultimate
# - Camera bob, recoil, shake and UI kick values
# - Animation loading and switching
# - Kill-based levelling
# - Stackable powerups
# - 2 active item slots
# - UI stat dictionary support
# - First-person head/helmet hiding
############################################################


############################################################
# NODE REFERENCES
############################################################

@export var camera: Camera3D
@export var animation_player: AnimationPlayer
@export var bullet_ray: RayCast3D

@export var character_root_name: String = "RaynaNova7-1rig"
@export var character_root: Node3D


############################################################
# FIRST-PERSON MODEL HIDING
#
# first_person_head_node_name should match the head mesh/node.
# Yours is currently called "Sphere".
############################################################

@export var first_person_head_node_name: String = "Sphere"
@export var first_person_hidden_meshes: Array[Node3D] = []


############################################################
# MOVEMENT
############################################################

@export var walk_speed: float = 7.0
@export var sprint_speed: float = 11.0
@export var jump_velocity: float = 5.0
@export var controller_deadzone: float = 0.18

var movement_input_strength: float = 0.0
var is_sprinting: bool = false


############################################################
# LOOK / CAMERA
############################################################

@export var normal_mouse_sensitivity: float = 0.2
@export var aim_mouse_sensitivity: float = 0.12

@export var normal_controller_sensitivity: float = 1.0
@export var aim_controller_sensitivity: float = 0.55

@export var normal_fov: float = 78.0
@export var aim_fov: float = 66.0

@export var first_person_camera_position: Vector3 = Vector3(0.0, 1.60, 0.0)
@export var camera_lerp_speed: float = 14.0
@export var camera_near_clip: float = 0.01

var rotation_x: float = 0.0
var rotation_y: float = 0.0
var is_aiming: bool = false


############################################################
# CAMERA BOB
#
# ui_walk_bob_kick is used by PlayerUI for helmet drift.
############################################################

@export var camera_bob_enabled: bool = true
@export var walk_bob_speed: float = 10.0
@export var sprint_bob_speed: float = 14.0
@export var walk_bob_amount: float = 0.035
@export var sprint_bob_amount: float = 0.055
@export var side_bob_amount: float = 0.018
@export var bob_return_speed: float = 10.0

var bob_timer: float = 0.0
var current_bob_offset: Vector3 = Vector3.ZERO
var ui_walk_bob_kick: Vector2 = Vector2.ZERO


############################################################
# HEALTH / STAMINA
############################################################

@export var max_health: float = 100.0
@export var heal_delay: float = 3.0
@export var heal_rate: float = 5.0
@export var armour: float = 1.0

@export var max_stamina: float = 100.0
@export var stamina_drain_speed: float = 30.0
@export var stamina_recovery_speed: float = 22.0
@export var minimum_stamina_to_sprint: float = 10.0
@export var stamina_recharge_delay: float = 1.2

var health: float = 100.0
var stamina: float = 100.0
var time_since_damage: float = 0.0
var stamina_recharge_timer: float = 0.0
var sprint_locked: bool = false


############################################################
# SHOOTING / RECOIL
############################################################

@export var weapon_damage: int = 45
@export var fire_rate: float = 0.22

@export var recoil_strength: float = 1.6
@export var recoil_recovery: float = 10.0

var can_shoot: bool = true
var is_firing: bool = false
var recoil: float = 0.0


############################################################
# DASH
############################################################

@export var dash_distance: float = 10.0
@export var dash_duration: float = 0.18
@export var dash_cooldown: float = 4.0
@export var dash_fov_bonus: float = 6.0

var can_dash: bool = true
var is_dashing: bool = false
var dash_timer: float = 0.0
var dash_speed: float = 0.0
var dash_direction: Vector3 = Vector3.ZERO


############################################################
# ULTIMATE
############################################################

@export var ultimate_damage: int = 60
@export var ultimate_range: float = 18.0
@export var ultimate_knockback: float = 18.0
@export var ultimate_cooldown: float = 90.0

var can_use_ultimate: bool = true


############################################################
# CAMERA SHAKE / UI KICKS
############################################################

@export var camera_shake_recovery: float = 10.0
@export var camera_shake_multiplier: float = 0.45

var camera_shake_strength: float = 0.0
var ui_recoil_kick: float = 0.0
var ui_jump_kick: float = 0.0


############################################################
# ANIMATIONS
#
# These match your AnimationPlayer dropdown:
# - Animations/rifle_idle
# - Animations/rifle_run
# - Animations/rifle_jump
# - Animations/rifle_jump_loop
############################################################

@export var idle_animation: String = "Animations/rifle_idle"
@export var run_animation: String = "Animations/rifle_run"
@export var jump_up_animation: String = "Animations/rifle_jump"
@export var jump_loop_animation: String = "Animations/rifle_jump_loop"

@export var animation_blend_time: float = 0.12
@export var idle_anim_speed: float = 1.0
@export var run_anim_speed: float = 1.0
@export var sprint_anim_speed: float = 1.35
@export var jump_anim_speed: float = 1.0

var current_animation: String = ""
var jump_up_started: bool = false
var jump_up_finished: bool = false


############################################################
# EXTERNAL ANIMATION LOADING
#
# Forces Godot to load your .anim files into the model at runtime.
# This fixes the issue where runtime only sees ["mixamo_com"].
############################################################

@export var load_external_animation_files: bool = true

@export var idle_animation_file: String = "res://Animations/rifle_idle.anim"
@export var run_animation_file: String = "res://Animations/rifle_run.anim"
@export var jump_up_animation_file: String = "res://Animations/rifle_jump.anim"
@export var jump_loop_animation_file: String = "res://Animations/rifle_jump_loop.anim"


############################################################
# LEVELS / KILLS / BASE STATS
############################################################

var player_level: int = 0
var total_kills: int = 0
var kills_this_level: int = 0

@export var base_kills_required: int = 5
@export var kills_required_growth: float = 1.25
@export var level_stat_growth: float = 0.05

var base_max_health: float
var base_max_stamina: float
var base_heal_rate: float
var base_armour: float
var base_walk_speed: float
var base_sprint_speed: float
var base_jump_velocity: float
var base_weapon_damage: int


############################################################
# STAT MULTIPLIERS / BONUSES
############################################################

var damage_multiplier: float = 1.0
var health_multiplier: float = 1.0
var regen_multiplier: float = 1.0
var armour_multiplier: float = 1.0
var speed_multiplier: float = 1.0
var jump_multiplier: float = 1.0

var flat_health_bonus: float = 0.0
var bonus_regen: float = 0.0

var crit_chance: float = 0.0
var crit_damage_multiplier: float = 1.5


############################################################
# POWERUPS / ACTIVE ITEMS
############################################################

var collected_powerups: Dictionary = {}

@export var max_active_items: int = 2
var active_items: Array[String] = []

@export var dagger_radius: float = 8.0
@export var dagger_damage_per_second: float = 10.0

@export var eyeballs_auto_attack_range: float = 25.0
@export var eyeballs_auto_attack_cooldown: float = 0.45
var eyeballs_timer: float = 0.0

@export var blood_magic_range: float = 22.0
@export var blood_magic_damage: int = 35
@export var blood_magic_cooldown: float = 0.8
var blood_magic_timer: float = 0.0


############################################################
# READY
############################################################

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	add_to_group("player")

	auto_find_nodes()
	force_correct_animation_player()
	load_external_animations_into_player()

	hide_first_person_head()
	hide_first_person_meshes()

	if camera != null:
		camera.near = camera_near_clip
		camera.position = first_person_camera_position
		camera.fov = normal_fov

	store_base_stats()
	apply_player_stats()

	health = max_health
	stamina = max_stamina

	print_animation_debug()
	force_play_animation(idle_animation, idle_anim_speed)


############################################################
# NODE SETUP
############################################################

func auto_find_nodes() -> void:
	if character_root == null:
		var found_root: Node = find_child(character_root_name, true, false)
		if found_root is Node3D:
			character_root = found_root as Node3D

	if camera == null:
		var found_camera: Node = find_child("Camera3D", true, false)
		if found_camera is Camera3D:
			camera = found_camera as Camera3D

	if bullet_ray == null and camera != null:
		var found_ray: Node = camera.find_child("BulletRay", true, false)
		if found_ray is RayCast3D:
			bullet_ray = found_ray as RayCast3D

	if bullet_ray == null:
		var any_ray: Node = find_child("BulletRay", true, false)
		if any_ray is RayCast3D:
			bullet_ray = any_ray as RayCast3D

	if animation_player == null and character_root != null:
		var found_anim: Node = character_root.find_child("AnimationPlayer", true, false)
		if found_anim is AnimationPlayer:
			animation_player = found_anim as AnimationPlayer

	if animation_player == null:
		var any_anim: Node = find_child("AnimationPlayer", true, false)
		if any_anim is AnimationPlayer:
			animation_player = any_anim as AnimationPlayer


func force_correct_animation_player() -> void:
	var exact_path: String = "VisualRoot/RaynaNova7-1rig/AnimationPlayer"

	if has_node(exact_path):
		animation_player = get_node(exact_path) as AnimationPlayer
		return

	if character_root != null:
		var found_anim: Node = character_root.find_child("AnimationPlayer", true, false)
		if found_anim is AnimationPlayer:
			animation_player = found_anim as AnimationPlayer


func store_base_stats() -> void:
	base_max_health = max_health
	base_max_stamina = max_stamina
	base_heal_rate = heal_rate
	base_armour = armour
	base_walk_speed = walk_speed
	base_sprint_speed = sprint_speed
	base_jump_velocity = jump_velocity
	base_weapon_damage = weapon_damage


func print_animation_debug() -> void:
	if animation_player == null:
		print("AnimationPlayer not found.")
		return

	print("AnimationPlayer found: ", animation_player.get_path())
	print("Available animations: ", animation_player.get_animation_list())


############################################################
# FIRST-PERSON HEAD HIDING
############################################################

func hide_first_person_head() -> void:
	if character_root == null:
		print("Could not hide head. Character root not found.")
		return

	var head_node: Node = character_root.find_child(first_person_head_node_name, true, false)

	if head_node == null:
		print("Head node not found: ", first_person_head_node_name)
		return

	print("Hiding first-person head: ", head_node.get_path())
	hide_geometry_recursive(head_node)


func hide_first_person_meshes() -> void:
	for mesh: Node3D in first_person_hidden_meshes:
		if mesh != null:
			hide_geometry_recursive(mesh)


func hide_geometry_recursive(node: Node) -> void:
	if node is GeometryInstance3D:
		var geo: GeometryInstance3D = node as GeometryInstance3D
		geo.visible = false
		geo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

	if node is Node3D:
		var node_3d: Node3D = node as Node3D
		node_3d.visible = false
		node_3d.scale = Vector3(0.001, 0.001, 0.001)

	for child: Node in node.get_children():
		hide_geometry_recursive(child)


############################################################
# EXTERNAL ANIMATION LOADING
############################################################

func load_external_animations_into_player() -> void:
	if animation_player == null:
		print("Cannot load external animations. AnimationPlayer is null.")
		return

	if not load_external_animation_files:
		return

	var library_name: String = "Animations"
	var animation_library: AnimationLibrary

	if animation_player.has_animation_library(library_name):
		animation_library = animation_player.get_animation_library(library_name)
	else:
		animation_library = AnimationLibrary.new()
		animation_player.add_animation_library(library_name, animation_library)

	add_animation_to_library(animation_library, "rifle_idle", idle_animation_file)
	add_animation_to_library(animation_library, "rifle_run", run_animation_file)
	add_animation_to_library(animation_library, "rifle_jump", jump_up_animation_file)
	add_animation_to_library(animation_library, "rifle_jump_loop", jump_loop_animation_file)


func add_animation_to_library(animation_library: AnimationLibrary, animation_name: String, file_path: String) -> void:
	if file_path == "":
		print("Empty animation path for: ", animation_name)
		return

	if not ResourceLoader.exists(file_path):
		print("Animation file does not exist: ", file_path)
		return

	var loaded_resource: Resource = load(file_path)

	if not loaded_resource is Animation:
		print("File is not an Animation resource: ", file_path)
		return

	if animation_library.has_animation(animation_name):
		animation_library.remove_animation(animation_name)

	animation_library.add_animation(animation_name, loaded_resource as Animation)


############################################################
# INPUT / PROCESS
############################################################

func _input(event: InputEvent) -> void:
	handle_mouse_look(event)

	if event.is_action_pressed("shoot"):
		is_firing = true
	elif event.is_action_released("shoot"):
		is_firing = false

	if event.is_action_pressed("aim"):
		is_aiming = true
	elif event.is_action_released("aim"):
		is_aiming = false

	if event.is_action_pressed("teleport"):
		start_dash()

	if event.is_action_pressed("ultimate"):
		use_ultimate()


func _process(delta: float) -> void:
	handle_controller_look(delta)
	update_health_regen(delta)
	update_camera(delta)
	update_recoil(delta)
	update_ui_kicks(delta)
	update_active_items(delta)

	if is_firing:
		shoot()


func _physics_process(delta: float) -> void:
	apply_gravity(delta)
	handle_jump()
	handle_dash(delta)
	handle_movement(delta)

	move_and_slide()
	update_animation()


############################################################
# LOOK
############################################################

func handle_mouse_look(event: InputEvent) -> void:
	if not event is InputEventMouseMotion:
		return

	var sensitivity: float = aim_mouse_sensitivity if is_aiming else normal_mouse_sensitivity

	rotation_y -= event.relative.x * sensitivity
	rotation_x -= event.relative.y * sensitivity
	rotation_x = clamp(rotation_x, -80.0, 80.0)

	rotation_degrees.y = rotation_y

	if camera != null:
		camera.rotation_degrees.x = rotation_x + recoil


func handle_controller_look(_delta: float) -> void:
	var stick: Vector2 = Vector2(
		Input.get_joy_axis(0, JOY_AXIS_RIGHT_X),
		Input.get_joy_axis(0, JOY_AXIS_RIGHT_Y)
	)

	if stick.length() < controller_deadzone:
		return

	var sensitivity: float = aim_controller_sensitivity if is_aiming else normal_controller_sensitivity

	rotation_y -= stick.x * sensitivity
	rotation_x -= stick.y * sensitivity
	rotation_x = clamp(rotation_x, -80.0, 80.0)

	rotation_degrees.y = rotation_y

	if camera != null:
		camera.rotation_degrees.x = rotation_x + recoil


############################################################
# MOVEMENT / STAMINA
############################################################

func get_movement_input() -> Vector2:
	var input_dir: Vector2 = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")

	input_dir.x += Input.get_joy_axis(0, JOY_AXIS_LEFT_X)
	input_dir.y += Input.get_joy_axis(0, JOY_AXIS_LEFT_Y)

	if input_dir.length() < controller_deadzone:
		return Vector2.ZERO

	return input_dir.limit_length(1.0)


func handle_movement(delta: float) -> void:
	if is_dashing:
		return

	var input_dir: Vector2 = get_movement_input()
	movement_input_strength = input_dir.length()

	var direction: Vector3 = transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)
	direction = direction.normalized()

	var wants_to_sprint: bool = Input.is_action_pressed("sprint") and movement_input_strength > 0.15

	if stamina <= 0.0:
		sprint_locked = true

	if stamina >= minimum_stamina_to_sprint:
		sprint_locked = false

	is_sprinting = wants_to_sprint and stamina > 0.0 and not sprint_locked

	var speed: float = sprint_speed if is_sprinting else walk_speed

	if is_sprinting:
		stamina -= stamina_drain_speed * delta
		stamina = maxf(stamina, 0.0)
		stamina_recharge_timer = stamina_recharge_delay

		if stamina <= 0.0:
			is_sprinting = false
			sprint_locked = true
	else:
		if stamina_recharge_timer > 0.0:
			stamina_recharge_timer -= delta
		else:
			stamina += stamina_recovery_speed * delta

	stamina = clamp(stamina, 0.0, max_stamina)

	if movement_input_strength > 0.15:
		velocity.x = direction.x * speed * movement_input_strength
		velocity.z = direction.z * speed * movement_input_strength
	else:
		movement_input_strength = 0.0
		velocity.x = move_toward(velocity.x, 0.0, walk_speed)
		velocity.z = move_toward(velocity.z, 0.0, walk_speed)


func apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta


func handle_jump() -> void:
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_velocity
		ui_jump_kick = 1.0
		jump_up_started = true
		jump_up_finished = false
		force_play_animation(jump_up_animation, jump_anim_speed)


############################################################
# HEALTH
############################################################

func update_health_regen(delta: float) -> void:
	if health <= 0.0 or health >= max_health:
		return

	time_since_damage += delta

	if time_since_damage >= heal_delay:
		health = clamp(health + get_effective_regen() * delta, 0.0, max_health)


func take_damage(amount: int) -> void:
	var reduced_damage: float = float(amount) / get_effective_armour()

	health = clamp(health - reduced_damage, 0.0, max_health)
	time_since_damage = 0.0

	add_camera_shake(0.35)
	print("Player Health: ", health)

	if health <= 0.0:
		die()


func heal(amount: float) -> void:
	health = clamp(health + amount, 0.0, max_health)


func die() -> void:
	print("Player Died")
	get_tree().reload_current_scene()


############################################################
# SHOOTING
############################################################

func shoot() -> void:
	if not can_shoot:
		return

	can_shoot = false

	recoil += recoil_strength
	ui_recoil_kick = 1.0
	add_camera_shake(0.08)

	get_tree().call_group("enemies", "hear_gunshot", global_position)

	if bullet_ray != null:
		bullet_ray.force_raycast_update()

		if bullet_ray.is_colliding():
			var target: Object = bullet_ray.get_collider()

			if target != null and target.has_method("take_damage"):
				target.take_damage(get_attack_damage())

	await get_tree().create_timer(fire_rate).timeout
	can_shoot = true


############################################################
# DASH / ULTIMATE
############################################################

func start_dash() -> void:
	if not can_dash or camera == null:
		return

	can_dash = false
	is_dashing = true
	dash_timer = dash_duration

	dash_direction = -camera.global_transform.basis.z
	dash_direction.y = 0.0
	dash_direction = dash_direction.normalized()

	dash_speed = dash_distance / dash_duration

	await get_tree().create_timer(dash_cooldown).timeout
	can_dash = true


func handle_dash(delta: float) -> void:
	if not is_dashing:
		return

	dash_timer -= delta

	velocity.x = dash_direction.x * dash_speed
	velocity.z = dash_direction.z * dash_speed

	if dash_timer <= 0.0:
		is_dashing = false


func use_ultimate() -> void:
	if not can_use_ultimate:
		return

	can_use_ultimate = false

	print("ULTIMATE ACTIVATED")
	add_camera_shake(0.85)

	for enemy: Node in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(enemy) or not enemy is Node3D:
			continue

		var enemy_3d: Node3D = enemy as Node3D
		var distance: float = global_position.distance_to(enemy_3d.global_position)

		if distance > ultimate_range:
			continue

		var direction: Vector3 = enemy_3d.global_position - global_position
		direction.y = 0.0
		direction = direction.normalized()

		if enemy_3d.has_method("apply_knockback"):
			enemy_3d.apply_knockback(direction * ultimate_knockback)

		if enemy_3d.has_method("take_damage"):
			var final_damage: int = int(round(float(ultimate_damage) * get_damage_multiplier()))
			enemy_3d.take_damage(final_damage)

	await get_tree().create_timer(ultimate_cooldown).timeout
	can_use_ultimate = true


############################################################
# CAMERA EFFECTS
############################################################

func update_camera(delta: float) -> void:
	if camera == null:
		return

	var target_position: Vector3 = first_person_camera_position
	target_position += get_camera_bob_offset(delta)
	target_position += get_camera_shake_offset(delta)

	camera.position = camera.position.lerp(target_position, camera_lerp_speed * delta)

	var target_fov: float = aim_fov if is_aiming else normal_fov

	if is_dashing:
		target_fov += dash_fov_bonus

	camera.fov = lerp(camera.fov, target_fov, 8.0 * delta)


func get_camera_bob_offset(delta: float) -> Vector3:
	if not camera_bob_enabled:
		current_bob_offset = current_bob_offset.lerp(Vector3.ZERO, bob_return_speed * delta)
		ui_walk_bob_kick = ui_walk_bob_kick.lerp(Vector2.ZERO, bob_return_speed * delta)
		return current_bob_offset

	var should_bob: bool = is_on_floor() and movement_input_strength > 0.15 and not is_dashing

	if should_bob:
		var active_bob_speed: float = sprint_bob_speed if is_sprinting else walk_bob_speed
		var active_bob_amount: float = sprint_bob_amount if is_sprinting else walk_bob_amount

		bob_timer += delta * active_bob_speed

		var vertical_bob: float = sin(bob_timer) * active_bob_amount
		var horizontal_bob: float = cos(bob_timer * 0.5) * side_bob_amount

		current_bob_offset = Vector3(horizontal_bob, vertical_bob, 0.0)
		ui_walk_bob_kick = Vector2(horizontal_bob * 70.0, vertical_bob * 55.0)
	else:
		bob_timer = 0.0
		current_bob_offset = current_bob_offset.lerp(Vector3.ZERO, bob_return_speed * delta)
		ui_walk_bob_kick = ui_walk_bob_kick.lerp(Vector2.ZERO, bob_return_speed * delta)

	return current_bob_offset


func update_recoil(delta: float) -> void:
	recoil = lerp(recoil, 0.0, recoil_recovery * delta)

	if camera != null:
		camera.rotation_degrees.x = rotation_x + recoil


func update_ui_kicks(delta: float) -> void:
	ui_jump_kick = lerp(ui_jump_kick, 0.0, 6.0 * delta)
	ui_recoil_kick = lerp(ui_recoil_kick, 0.0, 8.0 * delta)


func add_camera_shake(amount: float) -> void:
	camera_shake_strength = clamp(camera_shake_strength + amount * camera_shake_multiplier, 0.0, 1.0)


func get_camera_shake_offset(delta: float) -> Vector3:
	if camera_shake_strength <= 0.01:
		camera_shake_strength = 0.0
		return Vector3.ZERO

	var offset: Vector3 = Vector3(
		randf_range(-camera_shake_strength, camera_shake_strength),
		randf_range(-camera_shake_strength, camera_shake_strength),
		0.0
	) * 0.035

	camera_shake_strength = move_toward(camera_shake_strength, 0.0, camera_shake_recovery * delta)

	return offset


############################################################
# LEVELS / STATS
############################################################

func get_kills_required_for_next_level() -> int:
	return int(round(float(base_kills_required) * pow(kills_required_growth, float(player_level))))


func register_kill(enemy_max_health: float = 0.0) -> void:
	total_kills += 1
	kills_this_level += 1

	if has_powerup("Curse of Siphon") and enemy_max_health > 0.0:
		heal(enemy_max_health * 0.3)

	while kills_this_level >= get_kills_required_for_next_level():
		kills_this_level -= get_kills_required_for_next_level()
		level_up()


func level_up() -> void:
	player_level += 1
	apply_player_stats()
	print("LEVEL UP: ", player_level)


func set_player_level(new_level: int) -> void:
	player_level = maxi(new_level, 0)
	kills_this_level = 0
	apply_player_stats()
	print("Player Level: ", player_level)


func get_level_multiplier() -> float:
	return pow(1.0 + level_stat_growth, float(player_level))


func get_damage_multiplier() -> float:
	return get_level_multiplier() * damage_multiplier


func get_health_multiplier() -> float:
	return get_level_multiplier() * health_multiplier


func get_regen_multiplier() -> float:
	return get_level_multiplier() * regen_multiplier


func get_armour_multiplier() -> float:
	return get_level_multiplier() * armour_multiplier


func get_speed_multiplier() -> float:
	return speed_multiplier


func get_jump_multiplier() -> float:
	return jump_multiplier


func get_attack_damage() -> int:
	var final_damage: float = float(base_weapon_damage) * get_damage_multiplier()

	if randf() <= crit_chance:
		final_damage *= crit_damage_multiplier

	return int(round(final_damage))


func get_effective_regen() -> float:
	return (base_heal_rate * get_regen_multiplier()) + bonus_regen


func get_effective_armour() -> float:
	return maxf(base_armour * get_armour_multiplier(), 0.01)


func apply_player_stats() -> void:
	var old_max_health: float = max_health

	max_health = (base_max_health * get_health_multiplier()) + flat_health_bonus
	heal_rate = get_effective_regen()
	armour = get_effective_armour()

	walk_speed = base_walk_speed * get_speed_multiplier()
	sprint_speed = base_sprint_speed * get_speed_multiplier()
	jump_velocity = base_jump_velocity * get_jump_multiplier()

	weapon_damage = get_attack_damage()

	if max_health > old_max_health:
		health += max_health - old_max_health

	health = clamp(health, 0.0, max_health)
	stamina = clamp(stamina, 0.0, max_stamina)


############################################################
# POWERUPS
############################################################

func has_powerup(powerup_name: String) -> bool:
	return collected_powerups.has(powerup_name)


func add_powerup_count(powerup_name: String) -> void:
	if not collected_powerups.has(powerup_name):
		collected_powerups[powerup_name] = 0

	collected_powerups[powerup_name] += 1


func collect_powerup(powerup_name: String) -> void:
	add_powerup_count(powerup_name)

	match powerup_name:
		"Tentacle Flail":
			damage_multiplier *= 1.05

		"Stim Pack":
			flat_health_bonus += 25.0
			apply_player_stats()
			heal(100.0)

		"Blessings from the Gods":
			health_multiplier *= 1.05
			apply_player_stats()
			heal(50.0)

		"Steroids":
			bonus_regen += 5.0
			apply_player_stats()

		"Curse of Siphon":
			pass

		"Jet Boots":
			jump_multiplier *= 1.05

		"Enhanced Tendons":
			speed_multiplier *= 1.05

		_:
			print("Unknown powerup: ", powerup_name)

	apply_player_stats()
	print("Collected powerup: ", powerup_name)


############################################################
# ACTIVE ITEMS
############################################################

func collect_active_item(item_name: String) -> void:
	if active_items.has(item_name):
		print("Already have active item: ", item_name)
		return

	if active_items.size() >= max_active_items:
		print("Active item slots full")
		return

	active_items.append(item_name)
	print("Collected active item: ", item_name)


func has_active_item(item_name: String) -> bool:
	return active_items.has(item_name)


func update_active_items(delta: float) -> void:
	if has_active_item("Non-Euclidean Dagger"):
		update_non_euclidean_dagger(delta)

	if has_active_item("Jar of Eyeballs"):
		update_jar_of_eyeballs(delta)

	if has_active_item("Vial of Blood"):
		update_blood_magic(delta)


func update_non_euclidean_dagger(delta: float) -> void:
	for enemy: Node in get_tree().get_nodes_in_group("enemies"):
		if not enemy is Node3D:
			continue

		var enemy_3d: Node3D = enemy as Node3D

		if global_position.distance_to(enemy_3d.global_position) <= dagger_radius:
			if enemy_3d.has_method("take_damage"):
				var damage: int = int(round(dagger_damage_per_second * delta * get_damage_multiplier()))
				enemy_3d.take_damage(damage)


func update_jar_of_eyeballs(delta: float) -> void:
	eyeballs_timer -= delta

	if eyeballs_timer > 0.0:
		return

	var enemy: Node3D = get_nearest_enemy(eyeballs_auto_attack_range)

	if enemy != null and enemy.has_method("take_damage"):
		var damage: int = int(round(float(get_attack_damage()) * 1.5))
		enemy.take_damage(damage)
		eyeballs_timer = eyeballs_auto_attack_cooldown


func update_blood_magic(delta: float) -> void:
	blood_magic_timer -= delta

	if blood_magic_timer > 0.0:
		return

	var enemy: Node3D = get_nearest_enemy(blood_magic_range)

	if enemy != null and enemy.has_method("take_damage"):
		var damage: int = int(round(float(blood_magic_damage) * get_damage_multiplier()))
		enemy.take_damage(damage)
		blood_magic_timer = blood_magic_cooldown


func get_nearest_enemy(max_range: float) -> Node3D:
	var nearest_enemy: Node3D = null
	var nearest_distance: float = max_range

	for enemy: Node in get_tree().get_nodes_in_group("enemies"):
		if not enemy is Node3D:
			continue

		var enemy_3d: Node3D = enemy as Node3D
		var distance: float = global_position.distance_to(enemy_3d.global_position)

		if distance < nearest_distance:
			nearest_distance = distance
			nearest_enemy = enemy_3d

	return nearest_enemy


############################################################
# ANIMATIONS
############################################################

func update_animation() -> void:
	if animation_player == null:
		return

	var grounded: bool = is_on_floor()
	var moving: bool = movement_input_strength > 0.15

	if grounded:
		jump_up_started = false
		jump_up_finished = false

		if moving:
			var speed: float = sprint_anim_speed if is_sprinting else run_anim_speed
			play_animation(run_animation, speed)
		else:
			play_animation(idle_animation, idle_anim_speed)

		return

	if jump_up_started and not jump_up_finished:
		if current_animation != resolve_animation_name(jump_up_animation):
			force_play_animation(jump_up_animation, jump_anim_speed)
			return

		var pos: float = animation_player.current_animation_position
		var length: float = animation_player.current_animation_length

		if length > 0.0 and pos >= length - 0.05:
			jump_up_finished = true
			play_animation(jump_loop_animation, jump_anim_speed)

		return

	play_animation(jump_loop_animation, jump_anim_speed)


func resolve_animation_name(animation_name: String) -> String:
	if animation_player == null or animation_name == "":
		return ""

	if animation_player.has_animation(animation_name):
		return animation_name

	var target_short_name: String = animation_name.get_file()

	for available_name: String in animation_player.get_animation_list():
		if available_name == animation_name:
			return available_name

		if available_name.get_file() == target_short_name:
			return available_name

		if available_name.ends_with("/" + target_short_name):
			return available_name

		if available_name.ends_with(animation_name):
			return available_name

	return ""


func play_animation(animation_name: String, speed: float = 1.0) -> void:
	if animation_player == null or animation_name == "":
		return

	var resolved_name: String = resolve_animation_name(animation_name)

	if resolved_name == "":
		print("Missing animation: ", animation_name)
		print("Available animations: ", animation_player.get_animation_list())
		return

	animation_player.speed_scale = speed

	if current_animation == resolved_name:
		return

	current_animation = resolved_name
	animation_player.play(resolved_name, animation_blend_time)


func force_play_animation(animation_name: String, speed: float = 1.0) -> void:
	if animation_player == null or animation_name == "":
		return

	var resolved_name: String = resolve_animation_name(animation_name)

	if resolved_name == "":
		print("Missing animation: ", animation_name)
		print("Available animations: ", animation_player.get_animation_list())
		return

	current_animation = resolved_name
	animation_player.speed_scale = speed
	animation_player.play(resolved_name, animation_blend_time)


############################################################
# UI DATA
############################################################

func get_stats_for_ui() -> Dictionary:
	return {
		"level": player_level,
		"kills": total_kills,
		"kills_this_level": kills_this_level,
		"kills_required": get_kills_required_for_next_level(),

		"health": health,
		"max_health": max_health,
		"stamina": stamina,
		"max_stamina": max_stamina,

		"damage": get_attack_damage(),
		"regen": get_effective_regen(),
		"armour": get_effective_armour(),
		"walk_speed": walk_speed,
		"sprint_speed": sprint_speed,
		"jump_height": jump_velocity,

		"damage_multiplier": get_damage_multiplier(),
		"health_multiplier": get_health_multiplier(),
		"regen_multiplier": get_regen_multiplier(),
		"armour_multiplier": get_armour_multiplier(),
		"speed_multiplier": get_speed_multiplier(),
		"jump_multiplier": get_jump_multiplier(),

		"crit_chance": crit_chance,
		"crit_damage_multiplier": crit_damage_multiplier,

		"active_items": active_items,
		"powerups": collected_powerups
	}
